<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/ads.php';

header('Content-Type: text/plain; charset=utf-8');

echo "=== ad_bundle_json('ai_action') ===\n";
$bundle = ad_bundle_json('ai_action');
echo json_encode($bundle, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);