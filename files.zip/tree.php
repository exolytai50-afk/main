<?php
// tree_plain.php — текстовое дерево папок/файлов, удобно копировать в VS Code

$root = __DIR__;
$maxDepth = 10;

// Исключаем папки, которые не нужны в выводе
$exclude = ['.git', 'vendor', 'node_modules', 'cache', 'logs'];

function buildTreePlain($dir, $prefix = '', $isLast = true, $depth = 0, $maxDepth, $exclude) {
    if ($depth > $maxDepth) return;

    $entries = scandir($dir, SCANDIR_SORT_ASCENDING);
    $dirs = [];
    $files = [];

    foreach ($entries as $entry) {
        if (in_array($entry, ['.', '..'])) continue;
        if (in_array($entry, $exclude)) continue;

        $path = $dir . DIRECTORY_SEPARATOR . $entry;
        if (is_dir($path)) {
            $dirs[] = $entry;
        } else {
            $files[] = $entry;
        }
    }

    // Сначала папки, потом файлы (как в классическом tree)
    $items = array_merge($dirs, $files);

    foreach ($items as $i => $name) {
        $isLastItem = ($i === count($items) - 1);
        $connector = $isLastItem ? '└── ' : '├── ';
        $nextPrefix = $isLastItem ? '    ' : '│   ';

        echo $prefix . $connector . $name . PHP_EOL;

        $path = $dir . DIRECTORY_SEPARATOR . $name;
        if (is_dir($path)) {
            buildTreePlain($path, $prefix . $nextPrefix, $isLastItem, $depth + 1, $maxDepth, $exclude);
        }
    }
}

header('Content-Type: text/plain; charset=utf-8');
echo "Root: " . htmlspecialchars(basename($root), ENT_QUOTES, 'UTF-8') . PHP_EOL . PHP_EOL;
buildTreePlain($root, '', true, 0, $maxDepth, $exclude);
?>
