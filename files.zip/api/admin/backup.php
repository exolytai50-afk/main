<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$action = $_GET['action'] ?? '';
$backupDir = ROOT_DIR . '/backups';
if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);

try {
    if ($action === 'create') {
        $filename = 'backup_' . DB_NAME . '_' . date('Y-m-d_H-i-s') . '.sql';
        $filepath = $backupDir . '/' . $filename;
        
        // Создаём дамп
        $tables = db_all('SHOW TABLES');
        $dump = "-- GigaChefAI Backup\n-- " . date('Y-m-d H:i:s') . "\n\n";
        $dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
        
        foreach ($tables as $table) {
            $tableName = reset($table);
            $create = db_one("SHOW CREATE TABLE `{$tableName}`");
            $dump .= $create['Create Table'] . ";\n\n";
            
            $rows = db_all("SELECT * FROM `{$tableName}`");
            foreach ($rows as $row) {
                $values = array_map(fn($v) => $v === null ? 'NULL' : "'" . addslashes((string)$v) . "'", array_values($row));
                $dump .= "INSERT INTO `{$tableName}` VALUES (" . implode(',', $values) . ");\n";
            }
            $dump .= "\n";
        }
        
        $dump .= "SET FOREIGN_KEY_CHECKS=1;\n";
        file_put_contents($filepath, $dump);
        
        json_response(['ok' => true, 'url' => '/backups/' . $filename, 'filename' => $filename]);
    }
    
    if ($action === 'list') {
        $files = glob($backupDir . '/*.sql');
        $backups = [];
        foreach ($files as $file) {
            $backups[] = [
                'name' => basename($file),
                'size' => round(filesize($file) / 1024, 2) . ' KB',
                'url' => '/backups/' . basename($file)
            ];
        }
        json_response(['backups' => array_reverse($backups)]);
    }
    
    if ($action === 'delete') {
        $file = basename($_GET['file'] ?? '');
        $filepath = $backupDir . '/' . $file;
        if (file_exists($filepath)) unlink($filepath);
        json_response(['ok' => true]);
    }
    
    if ($action === 'restore' && isset($_FILES['backup'])) {
        $sql = file_get_contents($_FILES['backup']['tmp_name']);
        $queries = array_filter(explode(';', $sql), 'trim');
        foreach ($queries as $query) {
            if (trim($query)) db_exec($query);
        }
        json_response(['ok' => true]);
    }
    
} catch (Throwable $e) {
    json_response(['error' => $e->getMessage()], 500);
}