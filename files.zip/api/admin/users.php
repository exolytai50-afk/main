<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $search = trim($_GET['search'] ?? '');
        $role = trim($_GET['role'] ?? '');
        
        $where = [];
        $params = [];
        
        if ($search) {
            $where[] = '(u.email LIKE ? OR u.display_name LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        if ($role === 'premium') {
            $where[] = 'u.is_premium = 1';
        } elseif ($role) {
            $where[] = 'u.role = ?';
            $params[] = $role;
        }
        
        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $users = db_all(
            "SELECT u.*, 
                    COALESCE(us.recipes_created, 0) as recipes_count,
                    CASE WHEN s.status = 'active' AND s.subscription_end_date >= CURDATE() THEN 1 ELSE 0 END as has_active_subscription
             FROM users u
             LEFT JOIN user_stats us ON us.user_id = u.id
             LEFT JOIN subscriptions s ON s.user_email = u.email AND s.status = 'active'
             {$whereClause}
             ORDER BY u.id DESC
             LIMIT 100",
            $params
        );
        
        // Статистика
        $stats = [
            'total' => (int)(db_one("SELECT COUNT(*) as cnt FROM users")['cnt'] ?? 0),
            'users' => (int)(db_one("SELECT COUNT(*) as cnt FROM users WHERE role = 'user'")['cnt'] ?? 0),
            'admins' => (int)(db_one("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'")['cnt'] ?? 0),
            'premium' => (int)(db_one("SELECT COUNT(*) as cnt FROM users WHERE is_premium = 1")['cnt'] ?? 0),
        ];
        
        json_response(['users' => $users, 'stats' => $stats]);
    }
    
    if ($method === 'PUT') {
        $data = json_input();
        $id = (int)($data['id'] ?? 0);
        
        if ($id <= 0) {
            json_response(['error' => 'Не указан ID пользователя'], 400);
        }
        
        $updates = [];
        $params = [];
        
        // ✅ Проверяем через array_key_exists вместо isset
        // потому что isset(0) возвращает false
        
        if (array_key_exists('display_name', $data)) {
            $updates[] = 'display_name = ?';
            $params[] = trim((string)$data['display_name']);
        }
        if (array_key_exists('role', $data) && in_array($data['role'], ['user', 'admin'])) {
            $updates[] = 'role = ?';
            $params[] = $data['role'];
        }
        if (array_key_exists('points', $data)) {
            $updates[] = 'points = ?';
            $params[] = max(0, (int)$data['points']);
        }
        // ✅ Главное исправление: используем array_key_exists
        if (array_key_exists('is_premium', $data)) {
            $updates[] = 'is_premium = ?';
            $params[] = $data['is_premium'] ? 1 : 0;
            
            // Логируем для отладки
            error_log("Admin: setting is_premium to " . ($data['is_premium'] ? 1 : 0) . " for user {$id}");
        }
        if (array_key_exists('bio', $data)) {
            $updates[] = 'bio = ?';
            $params[] = trim((string)$data['bio']);
        }
        
        if (!empty($updates)) {
            $params[] = $id;
            $sql = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?';
            error_log("Admin SQL: {$sql} with params: " . json_encode($params));
            db_exec($sql, $params);
        }
        
        if (array_key_exists('is_premium', $data)) {
            // сбрасываем кэш текущего пользователя, если админ меняет себя
            current_user_flush_cache();
            // если меняют другого — его кэш живёт в его сессии, ничего не сделаем;
            // но так как кэш в $GLOBALS, следующий запрос того пользователя
            // прочитает свежее значение из БД
        }
        
        json_response(['ok' => true]);
    }
    
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            json_response(['error' => 'Не указан ID'], 400);
        }
        
        // Не даём удалить себя
        $currentUser = current_user();
        if ($id === (int)$currentUser['id']) {
            json_response(['error' => 'Нельзя удалить самого себя'], 400);
        }
        
        db_exec('DELETE FROM users WHERE id = ?', [$id]);
        db_exec('DELETE FROM user_stats WHERE user_id = ?', [$id]);
        
        json_response(['ok' => true]);
    }
    
    json_response(['error' => 'Метод не поддерживается'], 405);
    
} catch (Throwable $e) {
    error_log('Admin users error: ' . $e->getMessage());
    json_response(['error' => APP_DEBUG ? $e->getMessage() : 'Ошибка сервера'], 500);
}