<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/sitemap_generator.php';
require_admin_api();

$action = $_GET['action'] ?? '';

try {
    /* ────────────────────────────────────────────────────────────
       action=create  — сгенерировать sitemap.xml
       Параметры:
         ?recipes_limit=100|500|1000|5000|10000|20000
       ──────────────────────────────────────────────────────────── */
    if ($action === 'create') {
        $allowed = [100, 500, 1000, 5000, 10000, 20000];
        $limit   = (int)($_GET['recipes_limit'] ?? 1000);
        if (!in_array($limit, $allowed, true)) {
            $limit = 1000;
        }

        // Универсальная функция — она уже должна быть в sitemap_generator.php
        // Если называется по-другому — поправьте под свой код.
        $result = generate_sitemap($limit);

        json_response([
            'ok'          => true,
            'url'         => url('sitemap.xml'),
            'recipes'     => (int)($result['recipes']  ?? 0),
            'pages'       => (int)($result['pages']    ?? 0),
            'categories'  => (int)($result['categories'] ?? 0),
            'generated_at' => date('c'),
        ]);
    }

    /* ────────────────────────────────────────────────────────────
       action=info — показать текущее состояние sitemap.xml
       ──────────────────────────────────────────────────────────── */
    if ($action === 'info') {
        $file = ROOT_DIR . '/sitemap.xml';
        if (!file_exists($file)) {
            json_response([
                'ok'         => false,
                'exists'     => false,
                'message'    => 'sitemap.xml ещё не создан',
            ]);
        }

        $content  = file_get_contents($file);
        $urlCount = substr_count($content, '<url>');

        json_response([
            'ok'          => true,
            'exists'      => true,
            'url_count'   => $urlCount,
            'size'        => filesize($file),
            'generated_at' => date('c', filemtime($file)),
        ]);
    }

    json_response(['error' => 'Неизвестный action'], 400);

} catch (Throwable $e) {
    json_response([
        'error' => APP_DEBUG ? $e->getMessage() : 'Ошибка генерации',
    ], 500);
}