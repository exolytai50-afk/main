<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];

try {
    /* ════════════════════════════════════════════════════════════
       GET — список комментариев к отзывам
       Параметры:
         ?search=...      — поиск по тексту комментария
         ?rating=N        — фильтр по оценке отзыва (1–5)
         ?review_id=N     — только комментарии конкретного отзыва
       ════════════════════════════════════════════════════════════ */
    if ($method === 'GET') {
        $search   = trim($_GET['search'] ?? '');
        $rating   = (int)($_GET['rating'] ?? 0);
        $reviewId = (int)($_GET['review_id'] ?? 0);

        $where  = [];
        $params = [];

        if ($search !== '') {
            $where[]  = 'rc.text LIKE ?';
            $params[] = "%{$search}%";
        }
        if ($rating > 0) {
            $where[]  = 'rr.rating = ?';
            $params[] = $rating;
        }
        if ($reviewId > 0) {
            $where[]  = 'rc.review_id = ?';
            $params[] = $reviewId;
        }

        $sql = "SELECT
                    rc.id,
                    rc.review_id,
                    rc.user_email,
                    rc.parent_id,
                    rc.text,
                    rc.created_at,
                    rr.rating,
                    rr.recipe_id,
                    r.title       AS recipe_title,
                    r.slug        AS recipe_slug,
                    u.display_name AS author_name,
                    u.avatar_url,
                    u.avatar_emoji
                FROM recipe_comments rc
                LEFT JOIN recipe_reviews rr ON rr.id = rc.review_id
                LEFT JOIN recipes r         ON r.id  = rr.recipe_id
                LEFT JOIN users u           ON u.email = rc.user_email";

        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        $sql .= ' ORDER BY rc.created_at DESC LIMIT 200';

        $comments = db_all($sql, $params);

        json_response([
            'comments'  => $comments,
            'review_id' => $reviewId ?: null,
            'total'     => count($comments),
        ]);
    }

    /* ════════════════════════════════════════════════════════════
       PUT — редактирование ТОЛЬКО ТЕКСТА комментария
       Рейтинг здесь не меняется — он принадлежит отзыву (recipe_reviews).
       ════════════════════════════════════════════════════════════ */
    if ($method === 'PUT') {
        $data = json_input();
        $id   = (int)($data['id'] ?? 0);

        if ($id <= 0) {
            json_response(['error' => 'Некорректный ID'], 400);
        }

        $text = trim((string)($data['text'] ?? ''));

        db_exec(
            'UPDATE recipe_comments SET text = ? WHERE id = ?',
            [$text, $id]
        );

        json_response(['ok' => true, 'id' => $id]);
    }

    /* ════════════════════════════════════════════════════════════
       DELETE — удаление комментария вместе с вложенными ответами
       Отзыв (recipe_reviews) НЕ трогается — он отдельная сущность.
       ════════════════════════════════════════════════════════════ */
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);

        if ($id <= 0) {
            json_response(['error' => 'Некорректный ID'], 400);
        }

        // Удаляем сам комментарий и все дочерние (parent_id = id)
        db_exec(
            'DELETE FROM recipe_comments WHERE id = ? OR parent_id = ?',
            [$id, $id]
        );

        json_response(['ok' => true, 'id' => $id]);
    }

    /* ════════════════════════════════════════════════════════════
       Неизвестный метод
       ════════════════════════════════════════════════════════════ */
    json_response(['error' => 'Метод не поддерживается'], 405);

} catch (Throwable $e) {
    json_response([
        'error' => APP_DEBUG ? $e->getMessage() : 'Ошибка сервера'
    ], 500);
}