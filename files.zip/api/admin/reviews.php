<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];

try {
    /* ────────────────────────────────────────────────────────────
       GET — список отзывов
       ──────────────────────────────────────────────────────────── */
    if ($method === 'GET') {
        $search   = trim($_GET['search'] ?? '');
        $rating   = (int)($_GET['rating'] ?? 0);
        $recipeId = (int)($_GET['recipe_id'] ?? 0);

        $where  = [];
        $params = [];

        if ($search !== '') {
            $where[]  = '(rr.text LIKE ? OR r.title LIKE ? OR u.display_name LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        if ($rating > 0) {
            $where[]  = 'rr.rating = ?';
            $params[] = $rating;
        }
        if ($recipeId > 0) {
            $where[]  = 'rr.recipe_id = ?';
            $params[] = $recipeId;
        }

        $sql = "SELECT
                    rr.id,
                    rr.recipe_id,
                    rr.user_email,
                    rr.rating,
                    rr.text,
                    rr.created_at,
                    r.title  AS recipe_title,
                    r.slug   AS recipe_slug,
                    u.display_name,
                    u.avatar_url,
                    u.avatar_emoji,
                    (SELECT COUNT(*) FROM recipe_comments rc WHERE rc.review_id = rr.id) AS comments_count
                FROM recipe_reviews rr
                LEFT JOIN recipes r ON r.id = rr.recipe_id
                LEFT JOIN users u   ON u.email = rr.user_email";

        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY rr.created_at DESC LIMIT 200';

        $reviews = db_all($sql, $params);
        json_response(['reviews' => $reviews]);
    }

    /* ────────────────────────────────────────────────────────────
       PUT — редактирование текста/рейтинга отзыва
       ──────────────────────────────────────────────────────────── */
    if ($method === 'PUT') {
        $data = json_input();
        $id   = (int)($data['id'] ?? 0);

        if ($id <= 0) {
            json_response(['error' => 'Некорректный ID'], 400);
        }

        db_exec(
            'UPDATE recipe_reviews SET text = ?, rating = ? WHERE id = ?',
            [
                trim((string)($data['text'] ?? '')),
                max(1, min(5, (int)($data['rating'] ?? 5))),
                $id,
            ]
        );

        json_response(['ok' => true]);
    }

    /* ────────────────────────────────────────────────────────────
       DELETE — удаление отзыва вместе с его комментариями
       ──────────────────────────────────────────────────────────── */
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);

        if ($id <= 0) {
            json_response(['error' => 'Некорректный ID'], 400);
        }

        // Сначала комментарии, потом отзыв — чтобы не было «висячих»
        db_exec('DELETE FROM recipe_comments WHERE review_id = ?', [$id]);
        db_exec('DELETE FROM recipe_reviews WHERE id = ?', [$id]);

        json_response(['ok' => true]);
    }

    json_response(['error' => 'Метод не поддерживается'], 405);

} catch (Throwable $e) {
    json_response(['error' => APP_DEBUG ? $e->getMessage() : 'Ошибка сервера'], 500);
}