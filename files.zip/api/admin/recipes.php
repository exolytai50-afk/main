<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $search = trim($_GET['search'] ?? '');
        $filter = $_GET['filter'] ?? 'all';
        
        $where = [];
        $params = [];
        
        if ($search) {
            $where[] = 'r.title LIKE ?';
            $params[] = "%{$search}%";
        }
        if ($filter === 'ai') {
            $where[] = 'r.is_ai_generated = 1';
        } elseif ($filter === 'user') {
            $where[] = 'r.is_ai_generated = 0';
        }
        
        $sql = 'SELECT r.* FROM recipes r';
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY r.created_at DESC LIMIT 100';
        
        $recipes = db_all($sql, $params);
        json_response(['recipes' => $recipes]);
    }
    
    if ($method === 'PUT') {
        $data = json_input();
        $id = (int)($data['id'] ?? 0);
        
        db_exec(
            'UPDATE recipes SET title=?, description=?, cuisine=?, difficulty=?, calories=?, servings=?
             WHERE id=?',
            [
                $data['title'] ?? '',
                $data['description'] ?? '',
                $data['cuisine'] ?? '',
                $data['difficulty'] ?? 'Легко',
                (int)($data['calories'] ?? 0),
                (int)($data['servings'] ?? 1),
                $id
            ]
        );
        json_response(['ok' => true]);
    }
    
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        db_exec('DELETE FROM recipes WHERE id = ?', [$id]);
        db_exec('DELETE FROM comments WHERE recipe_id = ?', [$id]);
        db_exec('DELETE FROM favorites WHERE recipe_id = ?', [$id]);
        json_response(['ok' => true]);
    }
    
} catch (Throwable $e) {
    json_response(['error' => $e->getMessage()], 500);
}