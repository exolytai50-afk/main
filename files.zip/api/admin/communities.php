<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $communities = db_all('SELECT * FROM communities ORDER BY created_at DESC LIMIT 100');
        json_response(['communities' => $communities]);
    }
    
    if ($method === 'POST') {
        $data = json_input();
        $name = trim((string)($data['name'] ?? ''));
        
        if (empty($name)) {
            json_response(['error' => 'Название обязательно'], 400);
        }
        
        $slug = trim((string)($data['slug'] ?? ''));
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $name)) . '-' . substr(md5(uniqid()), 0, 6);
        }
        
        $id = db_insert(
            'INSERT INTO communities (name, slug, description, cover_emoji) VALUES (?, ?, ?, ?)',
            [
                $name,
                $slug,
                trim((string)($data['description'] ?? '')),
                trim((string)($data['cover_emoji'] ?? '🏘️'))
            ]
        );
        
        json_response(['ok' => true, 'id' => $id, 'slug' => $slug]);
    }
    
    if ($method === 'PUT') {
        $data = json_input();
        $id = (int)($data['id'] ?? 0);
        
        db_exec(
            'UPDATE communities SET name = ?, slug = ?, description = ?, cover_emoji = ? WHERE id = ?',
            [
                trim((string)($data['name'] ?? '')),
                trim((string)($data['slug'] ?? '')),
                trim((string)($data['description'] ?? '')),
                trim((string)($data['cover_emoji'] ?? '🏘️')),
                $id
            ]
        );
        
        json_response(['ok' => true]);
    }
    
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        db_exec('DELETE FROM community_members WHERE community_id = ?', [$id]);
        db_exec('DELETE FROM community_posts WHERE community_id = ?', [$id]);
        db_exec('DELETE FROM communities WHERE id = ?', [$id]);
        json_response(['ok' => true]);
    }
    
    json_response(['error' => 'Метод не поддерживается'], 405);
    
} catch (Throwable $e) {
    json_response(['error' => APP_DEBUG ? $e->getMessage() : 'Ошибка сервера'], 500);
}