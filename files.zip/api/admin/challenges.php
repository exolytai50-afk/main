<?php
/**
 * CRUD для челленджей в админке
 * GET /api/admin/challenges.php
 * POST /api/admin/challenges.php — создать
 * POST /api/admin/challenges.php?action=start_now&id=N — запустить
 * POST /api/admin/challenges.php?action=finish_now&id=N — завершить
 * PUT /api/admin/challenges.php — обновить
 * DELETE /api/admin/challenges.php?id=N — удалить
 */
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    // ===================== GET =====================
    if ($method === 'GET') {
        $rows = db_all(
            'SELECT c.*, 
                    (SELECT COUNT(*) FROM challenge_participants cp WHERE cp.challenge_id = c.id) AS participants_count,
                    (SELECT COUNT(*) FROM challenge_submissions cs WHERE cs.challenge_id = c.id) AS submissions_count
             FROM challenges c
             ORDER BY c.created_at DESC
             LIMIT 200'
        );
        json_response(['challenges' => $rows]);
    }

    // ===================== START NOW =====================
    if ($method === 'POST' && $action === 'start_now') {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) json_response(['error' => 'Не указан ID'], 400);

        $ch = db_one('SELECT category FROM challenges WHERE id = ?', [$id]);
        $days = match ($ch['category'] ?? 'standard') {
            'express'  => 3,
            'long'     => 14,
            'month'    => 30,
            default    => 7,
        };

        db_exec(
            'UPDATE challenges 
             SET status = "active",
                 starts_at = CURDATE(),
                 ends_at = DATE_ADD(CURDATE(), INTERVAL ? DAY)
             WHERE id = ?',
            [$days, $id]
        );

        json_response(['ok' => true, 'message' => 'Челлендж запущен']);
    }

    // ===================== FINISH NOW =====================
    if ($method === 'POST' && $action === 'finish_now') {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) json_response(['error' => 'Не указан ID'], 400);

        db_exec(
            'UPDATE challenges SET ends_at = DATE_SUB(CURDATE(), INTERVAL 1 DAY) WHERE id = ?',
            [$id]
        );

        json_response(['ok' => true, 'message' => 'Челлендж помечен на завершение']);
    }

    // ===================== POST (создание) =====================
    if ($method === 'POST') {
        $data = json_input();

        $title       = trim((string)($data['title'] ?? ''));
        $description = trim((string)($data['description'] ?? ''));
        $theme       = trim((string)($data['theme'] ?? ''));
        $category = in_array($data['category'] ?? '', ['express','standard','long','month'], true)
    ? $data['category'] : 'standard';
    
    $isThematic   = !empty($data['is_thematic']) ? 1 : 0;
$thematicDate = $isThematic && !empty($data['thematic_date']) 
    ? $data['thematic_date'] 
    : null;

$difficultyMap = [
    'express'  => 'easy',
    'standard' => 'medium',
    'long'     => 'hard',
    'month'    => 'hard',
];
$difficulty = $difficultyMap[$category] ?? 'medium';

        if ($title === '') {
            json_response(['error' => 'Название обязательно'], 400);
        }

        // Автогенерация
        $slug = generate_slug($title) . '-' . substr(md5(uniqid()), 0, 6);
        $auto = auto_fill_challenge($difficulty, $category, $title, $description, $theme);

        // Определяем даты
if ($isThematic && $thematicDate) {
    // Тематический: старт = thematic_date, конец = thematic_date + duration
    $startsAt = $thematicDate;
    $endsAt   = date('Y-m-d', strtotime($thematicDate . ' +' . $auto['duration_days'] . ' days'));
} else {
    // Обычный: старт = сегодня, конец = сегодня + duration
    $startsAt = date('Y-m-d');
    $endsAt   = date('Y-m-d', strtotime('+' . $auto['duration_days'] . ' days'));
}

$id = db_insert(
    'INSERT INTO challenges
     (title, slug, description, goal, theme, category, is_thematic, thematic_date,
      reward_points, difficulty, starts_at, ends_at, status, meta_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "draft", ?)',
    [
        $title, $slug, $description, $auto['goal'], $theme ?: $auto['theme'],
        $category, $isThematic, $thematicDate,
        $auto['reward_points'], $difficulty,
        $startsAt, $endsAt,
        json_encode($auto['meta_json'], JSON_UNESCAPED_UNICODE),
    ]
);

        json_response(['ok' => true, 'id' => $id, 'slug' => $slug]);
    }

// ===================== PUT =====================
if ($method === 'PUT') {
    $data = json_input();
    $id = (int)($data['id'] ?? 0);
    if ($id <= 0) json_response(['error' => 'Не указан ID'], 400);

    $title       = trim((string)($data['title'] ?? ''));
    $description = trim((string)($data['description'] ?? ''));
    $theme       = trim((string)($data['theme'] ?? ''));

    $category = in_array($data['category'] ?? '', ['express','standard','long','month'], true)
        ? $data['category'] : 'standard';

    $difficultyMap = [
        'express'  => 'easy',
        'standard' => 'medium',
        'long'     => 'hard',
        'month'    => 'hard',
    ];
    $difficulty = $difficultyMap[$category] ?? 'medium';

    $auto = auto_fill_challenge($difficulty, $category, $title, $description, $theme);
    $isThematic   = !empty($data['is_thematic']) ? 1 : 0;
    $thematicDate = $isThematic && !empty($data['thematic_date']) 
    ? $data['thematic_date'] 
    : null;

    // Определяем даты
if ($isThematic && $thematicDate) {
    $startsAt = $thematicDate;
    $endsAt   = date('Y-m-d', strtotime($thematicDate . ' +' . $auto['duration_days'] . ' days'));
} else {
    $startsAt = date('Y-m-d');
    $endsAt   = date('Y-m-d', strtotime('+' . $auto['duration_days'] . ' days'));
}

db_exec(
    'UPDATE challenges 
     SET title = ?, description = ?, theme = ?, goal = ?, category = ?, 
         is_thematic = ?, thematic_date = ?, 
         reward_points = ?, difficulty = ?, meta_json = ?,
         starts_at = ?, ends_at = ?
     WHERE id = ?',
    [
        $title, $description, $theme ?: $auto['theme'], $auto['goal'],
        $category, $isThematic, $thematicDate,
        $auto['reward_points'], $difficulty,
        json_encode($auto['meta_json'], JSON_UNESCAPED_UNICODE),
        $startsAt, $endsAt,
        $id
    ]
);

    json_response(['ok' => true]);
}

    // ===================== DELETE =====================
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        db_exec('DELETE FROM challenge_participants WHERE challenge_id = ?', [$id]);
        db_exec('DELETE FROM challenge_submissions WHERE challenge_id = ?', [$id]);
        db_exec('DELETE FROM challenges WHERE id = ?', [$id]);
        json_response(['ok' => true]);
    }

    json_response(['error' => 'Метод не поддерживается'], 405);

} catch (Throwable $e) {
    json_response(['error' => APP_DEBUG ? $e->getMessage() : 'Ошибка сервера'], 500);
}

// ═══════════════════════════════════════════════════
//  АВТОГЕНЕРАЦИЯ
// ═══════════════════════════════════════════════════

function auto_fill_challenge(string $difficulty, string $category, string $title, string $description, string $theme): array
{
    $categoryMap = [
        'express'  => ['duration_days' => 3,  'reward_points' => 30,  'goal' => 'Справиться за 3 дня'],
        'standard' => ['duration_days' => 7,  'reward_points' => 50,  'goal' => '7 дней — 7 блюд'],
        'long'     => ['duration_days' => 14, 'reward_points' => 100, 'goal' => '14 дней — глубокое погружение'],
        'month'    => ['duration_days' => 30, 'reward_points' => 200, 'goal' => '30 дней — полное погружение'],
    ];

    $preset = $categoryMap[$category] ?? $categoryMap['standard'];

    $days = [];
    for ($i = 1; $i <= $preset['duration_days']; $i++) {
        $days[] = ['day' => $i, 'task' => "День {$i}"];
    }

    return [
        'goal'          => $preset['goal'],
        'theme'         => $theme ?: 'Кулинария',
        'reward_points' => $preset['reward_points'],
        'category'      => $category,
        'duration_days' => $preset['duration_days'],
        'meta_json'     => [
            'short'    => $description,
            'long'     => trim($description . ' ' . $preset['goal']),
            'days'     => $days,
            'criteria' => ['Соответствие теме', 'Оригинальность', 'Презентация'],
        ],
    ];
}

function generate_slug(string $title): string
{
    $translit = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'yo',
        'ж'=>'zh','з'=>'z','и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m',
        'н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u',
        'ф'=>'f','х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch',
        'ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
        ' '=>'-','_'=>'-'
    ];
    $slug = strtr(mb_strtolower(trim($title)), $translit);
    $slug = preg_replace('/[^a-z0-9\-]/', '', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');
    return $slug !== '' ? $slug : 'challenge';
}