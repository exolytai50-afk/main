<?php
/**
 * POST /api/admin/maintenance.php
 * Body: { enabled: 0|1, until: "2026-09-28 18:00:00", message: "..." }
 * GET: возвращает текущее состояние
 */
declare(strict_types=1);
require_once __DIR__ . '/../../config/config.php';
require_admin_api();

header('Content-Type: application/json; charset=utf-8');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $s = maintenance_get_settings();
    json_response([
        'enabled' => $s['maintenance_enabled'] === '1',
        'until'   => $s['maintenance_until'],
        'message' => $s['maintenance_message'],
        'started_at' => $s['maintenance_started_at'],
    ]);
}

if ($method === 'POST') {
    $data = json_input();

    $enabled = !empty($data['enabled']) ? '1' : '0';
    $until   = trim((string)($data['until'] ?? ''));
    $message = trim((string)($data['message'] ?? ''));

    // Валидация даты
    if ($enabled === '1' && $until !== '' && strtotime($until) === false) {
        json_response(['error' => 'Неверный формат даты окончания'], 400);
    }

    maintenance_set('maintenance_enabled', $enabled);
    maintenance_set('maintenance_until', $until);
    maintenance_set('maintenance_message', $message);

    if ($enabled === '1') {
        maintenance_set('maintenance_started_at', date('Y-m-d H:i:s'));
        maintenance_set('maintenance_finished_notice_until', ''); // сбрасываем
    } else {
        // Выключили — показываем «Мы вернулись» 24 часа
        maintenance_set('maintenance_finished_notice_until', date('Y-m-d H:i:s', time() + 86400));
    }

    json_response([
        'ok' => true,
        'enabled' => $enabled === '1',
        'until' => $until,
    ]);
}

json_response(['error' => 'Метод не поддерживается'], 405);