/**
 * GigaChef — Безопасный Service Worker.
 * Кеширует ТОЛЬКО статику (js, css, картинки, шрифты).
 * HTML-страницы НИКОГДА не кешируются.
 */

const STATIC_CACHE = 'gigachef-static-v1';
const STATIC_RE = /\.(?:js|css|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|eot)$/i;

// 1. Установка: ничего не делаем, сразу активируемся
self.addEventListener('install', event => {
    self.skipWaiting();
});

// 2. Активация: удаляем ВСЕ старые кеши (включая PAGES_CACHE)
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys => {
            return Promise.all(
                keys.filter(k => k !== STATIC_CACHE).map(k => caches.delete(k))
            );
        }).then(() => self.clients.claim())
    );
});

// 3. Fetch: перехватываем только статику
self.addEventListener('fetch', event => {
    const req = event.request;
    
    // Только GET
    if (req.method !== 'GET') return;
    
    const url = new URL(req.url);
    
    // Только свой домен
    if (url.origin !== self.location.origin) return;
    
    // Только статика (js, css, картинки)
    if (!STATIC_RE.test(url.pathname)) return;
    
    // Не трогаем /api/, /admin/, /cron/
    if (/^\/(?:api|admin|cron)(?:\/|$)/.test(url.pathname)) return;

    // Стратегия: Cache First для статики с версией (?v=), Network First для остальной
    const isVersioned = url.searchParams.has('v');
    
    event.respondWith(
        caches.match(req).then(cached => {
            // Если версия есть — отдаём из кеша сразу
            if (cached && isVersioned) return cached;
            
            // Иначе грузим из сети
            return fetch(req).then(res => {
                // Кешируем только успешные ответы
                if (res && res.status === 200) {
                    const clone = res.clone();
                    caches.open(STATIC_CACHE).then(cache => cache.put(req, clone));
                }
                return res;
            }).catch(() => {
                // Если сети нет — отдаём из кеша (если есть)
                return cached || new Response('', { status: 504, statusText: 'Offline' });
            });
        })
    );
});